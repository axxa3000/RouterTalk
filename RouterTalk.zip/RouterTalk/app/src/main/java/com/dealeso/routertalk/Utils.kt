package com.dealeso.routertalk

import android.content.Context
import android.widget.Toast

val cookie_first = "Basic%20YnJ1bm86YjFmODU2NTNjY2Y2ZWMyNGIzY2RjMGIwZjZiMzI2ZDA%3D"
val cookie = "Basic%20YWRtaW46NmQyMzE1MmJiYTczNGFhZWIzZTcyMmYxYWNkMzlkMWM%3D"
val ssid = "Open_Wash_Cullera"
val ip = "192.168.0.1"
val welcome = "Ready to Hack&Roll? Lets play with: http://"
val connection_down =  " Wifi connection is not available "
val connection_up =  " Wifi connection is available "
val reboot_wait = " Please wait 10 seconds for router reboot "

fun Context.toast(message: String, length: Int = Toast.LENGTH_LONG) {
    Toast.makeText(this, message, length).show()
}