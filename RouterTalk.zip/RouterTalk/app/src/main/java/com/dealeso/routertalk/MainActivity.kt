package com.dealeso.routertalk

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.View
import io.github.rybalkinsd.kohttp.dsl.httpGet
import io.github.rybalkinsd.kohttp.ext.asString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    private var mainPresenter = MainPresenter(lifecycleScope) { justListeningToP(it) }

    private var broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val notConnected = intent.getBooleanExtra(
                ConnectivityManager
                .EXTRA_NO_CONNECTIVITY, false)
            if (notConnected) {
                disconnected()
            } else {
                connected()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        activity_main_feedback.movementMethod = ScrollingMovementMethod()
        activity_main_feedback.text = "$welcome$ip"

        btn_on.setOnClickListener {
            mainPresenter.routerGuestWifiOn(lifecycleScope)
        }
        btn_off.setOnClickListener {
            mainPresenter.routerGuestWifiOff(lifecycleScope)
        }
    }


    private fun justListeningToP(sign: SignalsFromPtoV): Unit  {

        when (sign) {
            is SignalsFromPtoV.activity_main_feedbackUpdate ->
                //binding.progress.visibility = if (sign1.value) View.VISIBLE else View.GONE
                activity_main_feedback.append(sign.value + System.getProperty("line.separator"))
            is SignalsFromPtoV.toast_reboot ->
                 toast ("$reboot_wait")

        }
    }
    override fun onStart() {
        super.onStart()
        registerReceiver(broadcastReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(broadcastReceiver)
    }

    private fun disconnected() {
       btn_on.visibility = View.INVISIBLE
       btn_off.visibility = View.INVISIBLE
       activity_main_feedback.append("$connection_down")

        //  imageView.visibility = View.VISIBLE
    }

    private fun connected() {

        btn_on.visibility = View.VISIBLE
        btn_off.visibility = View.VISIBLE
        activity_main_feedback.append("$connection_up")

        //   recyclerView.visibility = View.VISIBLE
     //   imageView.visibility = View.INVISIBLE
       // fetchFeeds()
    }


}
